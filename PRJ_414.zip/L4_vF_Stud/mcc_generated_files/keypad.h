void switch_press_scan(char *key_o, unsigned int *val_o);
void keypad_scanner(char *key_o, unsigned int *val_o);