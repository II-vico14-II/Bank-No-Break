/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.7
        Device            :  PIC16F1619
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
char Key = 'n'; 
unsigned int Val;
int counter;
int ID;
int Code;
int Val_mod;
int compteur =0;
char temp[13];

void main(void) {
  SYSTEM_Initialize();
  I2C_Master_Init();
  LCD_Init(0x4E); // Initialize LCD module with I2C address = 0x4E
  
    LCD_Clear();
    LCD_Set_Cursor(1, 1);
    LCD_Write_String("MasterCamp 2021");
    LCD_Set_Cursor(2, 1);
    LCD_Write_String("  EFREI Paris ");
    __delay_ms(1000);
    
    LCD_Clear();
    LCD_Set_Cursor(1, 1);
    LCD_Write_String("    Project ");
    LCD_Set_Cursor(2, 1);
    LCD_Write_String("Solution Factory");
    __delay_ms(2500);
    
    LCD_Clear();
    LCD_Set_Cursor(1, 1);
    LCD_Write_String("   Groupe 414  ");
    LCD_Set_Cursor(2, 1);
    LCD_Write_String(" Bank no Break");
    __delay_ms(2500);
    
    LCD_Clear();
    LCD_Set_Cursor(1, 1);
    LCD_Write_String("Press '*' to");
    LCD_Set_Cursor(2, 1);
    LCD_Write_String("accces ..");
    
    Key = 'n'; 
    while(Key != '*')               // Wait until '*' is pressed
    {
        keypad_scanner(&Key, &Val);
    }
    
    __delay_ms(1000);
// Completer le code
    
    while(!EUSART_is_tx_ready());
    EUSART_Write(Val);
    
    LCD_Clear();
    LCD_Set_Cursor(1, 1);
    LCD_Write_String("initialize FGPA");
    LCD_Set_Cursor(2, 1);
    LCD_Write_String("wait");
    
    __delay_ms(2000);
    


    while(compteur<3)
    {
        LCD_Clear();
        LCD_Set_Cursor(1, 1);
        LCD_Write_String("Enter password");
        LCD_Set_Cursor(2, 1);
        
        counter = 0;
        while( (counter<13))
        {
            switch_press_scan(&Key, &Val);
            LCD_Write_Char('*');
            ID = counter;
            ID &= 0x0F;
            ID <<=4;
            Code = Val;
            Code &= 0x0F;
            Val_mod = ID | Code;
            while(!EUSART_is_tx_ready());
            EUSART_Write(Val_mod);
            temp[counter]= Key;
            counter ++;
            
            
        }
       
        // Completer le code
        LCD_Clear();
        LCD_Set_Cursor(1, 1);
        LCD_Write_String("Press '#' to");
        LCD_Set_Cursor(2,1);
        LCD_Write_String("continue...");
        
        Key = 'n';
        
        while(Key != '#')
        {
            keypad_scanner(&Key, &Val);
            
        }
        
        while(!EUSART_is_tx_ready());
        EUSART_Write(Val);
        
        LCD_Clear();
        LCD_Set_Cursor(1, 1);
        LCD_Write_String("FPGA processing");
        LCD_Set_Cursor(2, 1);
        LCD_Write_String("Please Wait...");
        
        Code = EUSART_Read();
        RC1STA = 0x00;
        
        __delay_ms(2000);
        
        if(Code == 0xF1)
        {
            LCD_Clear();
            LCD_Set_Cursor(1, 1);
            LCD_Write_String("  Correct code");
            LCD_Set_Cursor(2, 1);
            LCD_Write_String("Access granted");
            __delay_ms(2000);
            LCD_Clear();
            LCD_Set_Cursor(1, 1);
            LCD_Write_String("   Strongbox");
            LCD_Set_Cursor(2, 1);
            LCD_Write_String("   Unlocked");
            __delay_ms(2000);
            
            LCD_Clear();
            LCD_Set_Cursor(1, 1);
            LCD_Write_String(temp);
            __delay_ms(2000);
            
            if (strcmp(temp,"0102199524587") == 0)
            {
                LCD_Clear();
                LCD_Set_Cursor(1, 1);
                LCD_Write_String("    Welcome");
                LCD_Set_Cursor(2, 1);
                LCD_Write_String("     Daniel");
                __delay_ms(5000);
            }
            else if (strcmp(temp,"1507198505678") == 0)
            {
                LCD_Clear();
                LCD_Set_Cursor(1, 1);
                LCD_Write_String("    Welcome");
                LCD_Set_Cursor(2, 1);
                LCD_Write_String("      Hugo");
                __delay_ms(5000);
            }
            else if (strcmp(temp,"230220002A5B4") == 0)
            {
                LCD_Clear();
                LCD_Set_Cursor(1, 1);
                LCD_Write_String("    Welcome");
                LCD_Set_Cursor(2, 1);
                LCD_Write_String("     Victor");
                __delay_ms(5000);
            }
            else if (strcmp(temp,"0409197535B9C") == 0)
            {
                LCD_Clear();
                LCD_Set_Cursor(1, 1);
                LCD_Write_String("    Welcome");
                LCD_Set_Cursor(2, 1);
                LCD_Write_String("    Calixte");
                __delay_ms(5000);
            }
            break;
        }
        
        else{
            LCD_Clear();
            LCD_Set_Cursor(1, 1);
            LCD_Write_String("  Wrong code");
            LCD_Set_Cursor(2, 1);
            LCD_Write_String("Access denied");
            LCD_Clear();
            LCD_Set_Cursor(1, 1);
            LCD_Write_String("   Strongbox");
            LCD_Set_Cursor(2, 1);
            LCD_Write_String("     Locked");
            compteur++;
            LCD_Clear();
            if(compteur == 1)
            {
              LCD_Set_Cursor(1, 1);
              LCD_Write_String("2 attempts left");
            }
            if(compteur ==2)
            {
              LCD_Set_Cursor(1, 1);
              LCD_Write_String("1 attempts left");
            }
        }
        __delay_ms(2000);
        
        if(compteur != 3 && Code != 0xF1)
        {
          LCD_Clear();
          LCD_Set_Cursor(1, 1);
          LCD_Write_String("Press '*' to");
          LCD_Set_Cursor(2, 1);
          LCD_Write_String("Try again");
          
          Key = 'n';
          
          while(Key != '*')
          {
              keypad_scanner(&Key, &Val);
          }
          RC1STA = 0x90;
          
          while(!EUSART_is_tx_ready())
          {
              EUSART_Write(Val);
              
              LCD_Clear();
              LCD_Set_Cursor(1, 1);
              LCD_Write_String("Initialize FPGA");
              LCD_Set_Cursor(2, 1);
              LCD_Write_String("Please Wait ...");
              
              __delay_ms(2000);
          }
        }

        else 
        {
            LCD_Clear();
            LCD_Set_Cursor(1, 1);
            LCD_Write_String("too many attempt");
            __delay_ms(2000);
            LCD_Clear();
            LCD_Set_Cursor(1, 1);
            LCD_Write_String("   Strongbox");
            LCD_Set_Cursor(2, 1);
            LCD_Write_String("     Locked");
              
            __delay_ms(2000);


        }


        
        
    }
        
}
/**
 End of File
*/